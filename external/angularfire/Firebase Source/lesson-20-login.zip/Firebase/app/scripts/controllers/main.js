'use strict';

angular.module('firebaseApp')
  .controller('MainCtrl', function () {


});
